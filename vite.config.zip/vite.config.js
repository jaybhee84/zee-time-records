import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

export default defineConfig({
  plugins: [react()],
  base: './', // Ensures relative asset paths for Electron (file:// protocol)
  server: {
    port: 5173,
    strictPort: true,
  },
  build: {
    outDir: 'dist',
    emptyOutDir: true,
    rollupOptions: {
      // Node-only modules used in the Electron main process must be
      // excluded from the Vite/Rollup renderer bundle or the build fails.
      external: ['mdb-reader'],
    },
  },
});